package com.example.ecuapp22;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class EighthActivity extends AppCompatActivity {

    private Button appButtons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eighth);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        appButtons = (Button) findViewById(R.id.button1);
        appButtons.setText("Password Reset");
        appButtons.setTextSize(26);
        appButtons.setAllCaps(false);
        appButtons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://www.ecok.edu/passreset/passreset.html"));
                startActivity(browserIntent);
            }
        });

        appButtons = (Button) findViewById(R.id.button2);
        appButtons.setText("MyECU");
        appButtons.setTextSize(26);
        appButtons.setAllCaps(false);
        appButtons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://myecu.ecok.edu/ics/"));
                startActivity(browserIntent);
            }
        });

        appButtons = (Button) findViewById(R.id.button3);
        appButtons.setText("Blackboard");
        appButtons.setTextSize(26);
        appButtons.setAllCaps(false);
        appButtons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://blackboard.ecok.edu/webapps/login/"));
                startActivity(browserIntent);
            }
        });

        appButtons = (Button) findViewById(R.id.button4);
        appButtons.setText("Campus Email");
        appButtons.setTextSize(26);
        appButtons.setAllCaps(false);
        appButtons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://login.microsoftonline.com/"));
                startActivity(browserIntent);
            }
        });

        appButtons = (Button) findViewById(R.id.button5);
        appButtons.setText("Finals Schedule");
        appButtons.setTextSize(26);
        appButtons.setAllCaps(false);
        appButtons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveToActivityFinals();
            }
        });

    }

    private void moveToActivityFinals() {

        Intent intent = new Intent(EighthActivity.this, Finals.class);
        startActivity(intent);
    }
}
