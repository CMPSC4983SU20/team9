package com.example.ecuapp22;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FirstActivity extends AppCompatActivity {
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        listView = (ListView)findViewById(R.id.AssignListView);
        String[] values = new String[]{"All Calendars", "Academic Calendar", "Athletics Calendar", "Campus Events"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.activity_list_item,android.R.id.text1,values) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView tv = (TextView) view.findViewById(android.R.id.text1);
                tv.setTextColor(Color.BLACK);
                tv.setPadding(0,50,0,50);
                tv.setTextSize(20);
                tv.setGravity(50);
                return view;
            }
        };
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id) {
                        if (position == 0){
                            Intent myintent = new Intent(view.getContext(),AllCal.class);
                            startActivityForResult(myintent, 0);
                        }
                        if (position == 1){
                            Intent myintent = new Intent(view.getContext(),AcademicCal.class);
                            startActivityForResult(myintent, 1);
                        }
                        if (position == 2){
                            Intent myintent = new Intent(view.getContext(),AthleticsCal.class);
                            startActivityForResult(myintent, 2);
                        }
                        if (position == 3){
                            Intent myintent = new Intent(view.getContext(),CampusCal.class);
                            startActivityForResult(myintent, 3);
                        }

                    }
                });
            }
        });
    }
}
